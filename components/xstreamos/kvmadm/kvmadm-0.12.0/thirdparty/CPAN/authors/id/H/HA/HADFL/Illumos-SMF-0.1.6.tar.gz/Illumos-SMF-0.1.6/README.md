Illumos::SMF
============

[![Build Status](https://travis-ci.org/hadfl/Illumos-SMF.svg?branch=master)](https://travis-ci.org/hadfl/Illumos-SMF)

A Perl Module to administrate Illumos SMF.
